#' Indirect GARCH estimation function
#'
#' Function for obtaining the Indirect GARCH \insertCite{engle_manganelli_2004}{rqmidas} specification.
#' @param param Indirect GARCH parameters to be estimated, that is: \eqn{\beta_1}, \eqn{\beta_2}, and \eqn{\beta_3}.
#' @param ret Daily returns.
#' @param alpha Quantile used.
#' @return The resulting vector represents the values of the Quantile Loss obtained from the Indirect GARCH.
#' @importFrom Rdpack reprompt
#' @keywords internal

ig_fun <- function(param, ret, tau){

b1 <- param[1] 
b2 <- param[2] 
b3 <- param[3]

N<-length(ret)
VaR_t <- rep(NA,N) 
VaR_t[1] <- quantile(ret,tau)

    for(i in 2:N) {
      VaR_t[i] <- c(- (b1 + b2 * VaR_t[i-1]^2 + b3 * ret[i-1]^2)^(0.5))
    }

    est<- -QL(ret,VaR_t,tau)
    #est<- -mean(est)
    est
  }

#' Indirect GARCH estimation function via ALD with ES
#'
#' Function for obtaining the Indirect GARCH \insertCite{engle_manganelli_2004}{rqmidas} specification.
#' @param param Indirect GARCH parameters to be estimated, that is: \eqn{\beta_1}, \eqn{\beta_2}, and \eqn{\beta_3}.
#' @param ret Daily returns.
#' @param alpha Quantile used.
#' @return The resulting vector represents the values of the Quantile Loss obtained from the Symmetric Absolute Value.
#' @importFrom Rdpack reprompt
#' @keywords internal

ig_fun_es <- function(param, ret, tau){

b1 <- param[1] 
b2 <- param[2] 
b3 <- param[3]
theta_gamma<-param[4]

N<-length(ret)
VaR_t<- rep(NA,N)
VaR_t[1] <- quantile(ret,tau)

 for(i in 2:N) {
      VaR_t[i] <-  c(- (b1 + b2 * VaR_t[i-1]^2 + b3 * ret[i-1]^2)^(0.5))
    }

es<-(1+exp(theta_gamma))*VaR_t
es<- -abs(es)
num_llk<-QL(ret,VaR_t,tau)
den_llk<-tau*es

llk<-(tau-1)*(es)^-1*exp(num_llk/den_llk)

return(log(llk))

}

#' Indirect GARCH function to obtain the Value-at-Risk
#'
#' Function for obtaining the Value-at-Risk from the Indirect GARCH \insertCite{engle_manganelli_2004}{rqmidas} specification.
#' @param param Indirect GARCH parameters used to obtain the Value-at-Risk, that is: \eqn{\beta_1}, \eqn{\beta_2}, and \eqn{\beta_3}.
#' @param ret Daily returns.
#' @param alpha Quantile used.
#' @return The resulting vector represents the values of the Value-at-Risk obtained from the Indirect GARCH model.
#' @importFrom Rdpack reprompt
#' @keywords internal

ig_var <- function(param, ret, tau){

b1 <- param[1] 
b2 <- param[2] 
b3 <- param[3]

N<-length(ret)
VaR_t <- rep(NA,N) 
VaR_t[1] <- quantile(ret,tau)

    for(i in 2:N) {
      VaR_t[i] <- c(- (b1 + b2 * VaR_t[i-1]^2 + b3 * ret[i-1]^2)^(0.5))
    }

    return(VaR_t)

}

#' Indirect GARCH with Double Asymmetric MIDAS estimation function
#'
#' Function for obtaining the Indirect GARCH \insertCite{engle_manganelli_2004}{rqmidas} specification.
#' @param param Indirect GARCH parameters to be estimated, that is: \eqn{\beta_1}, \eqn{\beta_2}, and \eqn{\beta_3}.
#' @param ret Daily returns.
#' @param mv_m. MIDAS variable already transformed into a matrix, through \code{\link[rumidas]{mv_into_mat}} function.
#' @param K. Number of (lagged) realizations of the MIDAS variable to consider.
#' @param alpha Quantile used.
#' @return The resulting vector represents the values of the Quantile Loss obtained from the Indirect GARCH.
#' @importFrom Rdpack reprompt
#' @keywords internal

ig_da_midas_fun <- function(param, ret, mv_m, K, tau){

b1 <- param[1] 
b2 <- param[2] 
b3 <- param[3]
theta_p <- param[4] 
w1<-1
w2_p <- param[5]  
theta_n <- param[6] 
w2_n <- param[7]

N<-length(ret)
VaR_t<- rep(NA,N) 
VaR_t[1] <- quantile(ret,tau)

mv_m_p<-ifelse(mv_m>=0,mv_m,0)
mv_m_n<-ifelse(mv_m<0,mv_m,0)

betas_p<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_p))[2:(K+1)],0)
tau_d_p<- suppressWarnings(roll::roll_sum(mv_m_p, c(K+1),weights = betas_p))
tau_d_p<-tau_d_p[(K+1),]	 

betas_n<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_n))[2:(K+1)],0)
tau_d_n<- suppressWarnings(roll::roll_sum(mv_m_n, c(K+1),weights = betas_n))
tau_d_n<-tau_d_n[(K+1),]	 


    for(i in 2:N) {
      VaR_t[i] <- c(- (b1 + b2 * VaR_t[i-1]^2 + b3 * ret[i-1]^2 + theta_p*tau_d_p[i-1]+
			theta_n*tau_d_n[i-1]  )^(0.5))
    }

    est<- -QL(ret,VaR_t,tau)
    #est<- -mean(est)
    est
  }

#' Indirect GARCH with Double Asymmetric MIDAS function to obtain the Value-at-Risk
#'
#' Function for obtaining the Indirect GARCH \insertCite{engle_manganelli_2004}{rqmidas} specification.
#' @param param Indirect GARCH parameters to be estimated, that is: \eqn{\beta_1}, \eqn{\beta_2}, and \eqn{\beta_3}.
#' @param ret Daily returns.
#' @param mv_m. MIDAS variable already transformed into a matrix, through \code{\link[rumidas]{mv_into_mat}} function.
#' @param K. Number of (lagged) realizations of the MIDAS variable to consider.
#' @param alpha Quantile used.
#' @return The resulting vector represents the values of the Quantile Loss obtained from the Indirect GARCH.
#' @importFrom Rdpack reprompt
#' @keywords internal

ig_da_midas_var <- function(param, ret, mv_m, K, tau){

b1 <- param[1] 
b2 <- param[2] 
b3 <- param[3]
theta_p <- param[4] 
w1<-1
w2_p <- param[5]  
theta_n <- param[6] 
w2_n <- param[7]

N<-length(ret)
VaR_t<- rep(NA,N)
VaR_t[1] <- quantile(ret,tau)

mv_m_p<-ifelse(mv_m>=0,mv_m,0)
mv_m_n<-ifelse(mv_m<0,mv_m,0)

betas_p<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_p))[2:(K+1)],0)
tau_d_p<- suppressWarnings(roll::roll_sum(mv_m_p, c(K+1),weights = betas_p))
tau_d_p<-tau_d_p[(K+1),]	 

betas_n<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_n))[2:(K+1)],0)
tau_d_n<- suppressWarnings(roll::roll_sum(mv_m_n, c(K+1),weights = betas_n))
tau_d_n<-tau_d_n[(K+1),]	 


    for(i in 2:N) {
      VaR_t[i] <- c(- (b1 + b2 * VaR_t[i-1]^2 + b3 * ret[i-1]^2 + theta_p*tau_d_p[i-1]+
			theta_n*tau_d_n[i-1]  )^(0.5))
    }

    return(VaR_t)

  }


#' Symmetric Absolute Value estimation function
#'
#' Function for obtaining the Symmetric Absolute Value \insertCite{engle_manganelli_2004}{rqmidas} specification.
#' @param param Symmetric Absolute Value parameters to be estimated, that is: \eqn{\beta_0}, \eqn{\beta_1}, and \eqn{\beta_2}.
#' @param ret Daily returns.
#' @param alpha Quantile used.
#' @return The resulting vector represents the values of the Quantile Loss obtained from the Symmetric Absolute Value.
#' @importFrom Rdpack reprompt
#' @keywords internal

sav_fun <- function(param, ret, tau){

b0 <- param[1] 
b1 <- param[2] 
b2 <- param[3]

N<-length(ret)
VaR_t<- rep(NA,N)
VaR_t[1] <- quantile(ret,tau)

 for(i in 2:N) {
      VaR_t[i] <- b0 + b1 * VaR_t[i-1]  + b2*abs(ret[i-1])
    }

    est<- -QL(ret,VaR_t,tau)
    #est<- -mean(est)
    est
  }

#' Symmetric Absolute Value estimation function via ALD with ES
#'
#' Function for obtaining the Symmetric Absolute Value \insertCite{engle_manganelli_2004}{rqmidas} specification.
#' @param param Symmetric Absolute Value parameters to be estimated, that is: \eqn{\beta_0}, \eqn{\beta_1}, and \eqn{\beta_2}.
#' @param ret Daily returns.
#' @param alpha Quantile used.
#' @return The resulting vector represents the values of the Quantile Loss obtained from the Symmetric Absolute Value.
#' @importFrom Rdpack reprompt
#' @keywords internal

sav_fun_es <- function(param, ret, tau){

b0 <- param[1] 
b1 <- param[2] 
b2 <- param[3]
theta_gamma<-param[4]

N<-length(ret)
VaR_t<- rep(NA,N)
VaR_t[1] <- quantile(ret,tau)

 for(i in 2:N) {
      VaR_t[i] <- b0 + b1 * VaR_t[i-1]  + b2*abs(ret[i-1])
    }

es<-(1+exp(theta_gamma))*VaR_t
es<- -abs(es)
num_llk<-QL(ret,VaR_t,tau)
den_llk<-tau*es

llk<-(tau-1)*(es)^-1*exp(num_llk/den_llk)

return(log(llk))

  }



#' Symmetric Absolute Value function to obtain the Value-at-Risk
#'
#' Function for obtaining the Value-at-Risk from the Symmetric Absolute Value \insertCite{engle_manganelli_2004}{rqmidas} specification.
#' @param param Symmetric Absolute Value parameters estimated, that is: \eqn{\beta_0}, \eqn{\beta_1}, and \eqn{\beta_2}.
#' @param ret Daily returns.
#' @param alpha Quantile used.
#' @return The resulting vector represents the values of the Value-at-Risk from the Symmetric Absolute Value model.
#' @importFrom Rdpack reprompt
#' @keywords internal

sav_var <- function(param, ret, tau){

b0 <- param[1] 
b1 <- param[2] 
b2 <- param[3]

N<-length(ret)
VaR_t<- rep(NA,N)
VaR_t[1] <- quantile(ret,tau)

 for(i in 2:N) {
      VaR_t[i] <- b0 + b1 * VaR_t[i-1]  + b2*abs(ret[i-1])
    }

    return(VaR_t)

  }

#' Symmetric Absolute Value with Double Asymmetric MIDAS estimation function
#'
#' Function for obtaining the Symmetric Absolute Value \insertCite{engle_manganelli_2004}{rqmidas} specification with Double Asymmetric MIDAS terms.
#' @param param Symmetric Absolute Value parameters to be estimated, that is: \eqn{\beta_0}, \eqn{\beta_1}, \eqn{\beta_2}, \eqn{\theta^{+}}, \eqn{\theta^{-}},
#' \eqn{\omega_2^{+}} and \eqn{\omega_2^{-}}.
#' @param ret Daily returns.
#' @param mv_m. MIDAS variable already transformed into a matrix, through \code{\link[rumidas]{mv_into_mat}} function.
#' @param K. Number of (lagged) realizations of the MIDAS variable to consider.
#' @param alpha Quantile used.
#' @return The resulting vector represents the values of the Quantile Loss obtained from the Symmetric Absolute Value Double Asymmetric MIDAS.
#' @importFrom Rdpack reprompt
#' @keywords internal

sav_da_midas_fun <- function(param, ret, mv_m, K, tau){

b0 <- param[1] 
b1 <- param[2] 
b2 <- param[3]
theta_p <- param[4] 
w1<-1
w2_p <- param[5]  
theta_n <- param[6] 
w2_n <- param[7]  

N<-length(ret)
VaR_t<- rep(NA,N) 
VaR_t[1] <- quantile(ret, p = tau)

mv_m_p<-ifelse(mv_m>=0,mv_m,0)
mv_m_n<-ifelse(mv_m<0,mv_m,0)

betas_p<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_p))[2:(K+1)],0)
tau_d_p<- suppressWarnings(roll::roll_sum(mv_m_p, c(K+1),weights = betas_p))
tau_d_p<-tau_d_p[(K+1),]	 

betas_n<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_n))[2:(K+1)],0)
tau_d_n<- suppressWarnings(roll::roll_sum(mv_m_n, c(K+1),weights = betas_n))
tau_d_n<-tau_d_n[(K+1),]	 

 for(i in 2:N) {
      VaR_t[i] <- b0 + b1 * VaR_t[i-1]  + b2*abs(ret[i-1]) + theta_p*tau_d_p[i-1]+
			theta_n*tau_d_n[i-1]  
    }

    est<- -QL(ret,VaR_t,tau)
    est<- #-mean(est)
    est
  }

#' Symmetric Absolute Value with Double Asymmetric MIDAS terms to obtain the Value-at-Risk
#'
#' Function for obtaining the Value-at-Risk from from the Symmetric Absolute Value \insertCite{engle_manganelli_2004}{rqmidas} specification with Double Asymmetric MIDAS terms.
#' @param param Symmetric Absolute Value parameters to be estimated, that is: \eqn{\beta_0}, \eqn{\beta_1}, \eqn{\beta_2}, \eqn{\theta^{+}}, \eqn{\theta^{-}},
#' \eqn{\omega_2^{+}} and \eqn{\omega_2^{-}}.
#' @param ret Daily returns.
#' @param mv_m. MIDAS variable already transformed into a matrix, through \code{\link[rumidas]{mv_into_mat}} function.
#' @param K. Number of (lagged) realizations of the MIDAS variable to consider.
#' @param alpha Quantile used.
#' @return The resulting vector represents the values of the Quantile Loss obtained from the Symmetric Absolute Value Double Asymmetric MIDAS.
#' @importFrom Rdpack reprompt
#' @keywords internal

sav_da_midas_var <- function(param, ret, mv_m, K, tau){

b0 <- param[1] 
b1 <- param[2] 
b2 <- param[3]
theta_p <- param[4] 
w1<-1
w2_p <- param[5]  
theta_n <- param[6] 
w2_n <- param[7]  

N<-length(ret)
VaR_t<- rep(NA,N) 
VaR_t[1] <- quantile(ret,tau)

mv_m_p<-ifelse(mv_m>=0,mv_m,0)
mv_m_n<-ifelse(mv_m<0,mv_m,0)

betas_p<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_p))[2:(K+1)],0)
tau_d_p<- suppressWarnings(roll::roll_sum(mv_m_p, c(K+1),weights = betas_p))
tau_d_p<-tau_d_p[(K+1),]	 

betas_n<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_n))[2:(K+1)],0)
tau_d_n<- suppressWarnings(roll::roll_sum(mv_m_n, c(K+1),weights = betas_n))
tau_d_n<-tau_d_n[(K+1),]	 

 for(i in 2:N) {
      VaR_t[i] <- b0 + b1 * VaR_t[i-1]  + b2*abs(ret[i-1]) + theta_p*tau_d_p[i-1]+
			theta_n*tau_d_n[i-1]  
    }

  return(VaR_t)  
  }

#' Symmetric Absolute Value with Double Asymmetric MIDAS estimation function via ALD with ES
#'
#' Function for obtaining the Symmetric Absolute Value \insertCite{engle_manganelli_2004}{rqmidas} specification with Double Asymmetric MIDAS terms.
#' @param param Symmetric Absolute Value parameters to be estimated, that is: \eqn{\beta_0}, \eqn{\beta_1}, \eqn{\beta_2}, \eqn{\theta^{+}}, \eqn{\theta^{-}},
#' \eqn{\omega_2^{+}} and \eqn{\omega_2^{-}}.
#' @param ret Daily returns.
#' @param mv_m. MIDAS variable already transformed into a matrix, through \code{\link[rumidas]{mv_into_mat}} function.
#' @param K. Number of (lagged) realizations of the MIDAS variable to consider.
#' @param alpha Quantile used.
#' @return The resulting vector represents the values of the Quantile Loss obtained from the Symmetric Absolute Value Double Asymmetric MIDAS.
#' @importFrom Rdpack reprompt
#' @keywords internal

sav_da_midas_fun_es <- function(param, ret, mv_m, K, tau){

b0 <- param[1] 
b1 <- param[2] 
b2 <- param[3]
theta_p <- param[4] 
w1<-1
w2_p <- param[5]  
theta_n <- param[6] 
w2_n <- param[7]  
theta_gamma<-param[8]

N<-length(ret)
VaR_t<- rep(NA,N) 
VaR_t[1] <- quantile(ret, p = tau)

mv_m_p<-ifelse(mv_m>=0,mv_m,0)
mv_m_n<-ifelse(mv_m<0,mv_m,0)

betas_p<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_p))[2:(K+1)],0)
tau_d_p<- suppressWarnings(roll::roll_sum(mv_m_p, c(K+1),weights = betas_p))
tau_d_p<-tau_d_p[(K+1),]	 

betas_n<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_n))[2:(K+1)],0)
tau_d_n<- suppressWarnings(roll::roll_sum(mv_m_n, c(K+1),weights = betas_n))
tau_d_n<-tau_d_n[(K+1),]	 

 for(i in 2:N) {
      VaR_t[i] <- b0 + b1 * VaR_t[i-1]  + b2*abs(ret[i-1]) + theta_p*tau_d_p[i-1]+
			theta_n*tau_d_n[i-1]  
    }

es<-(1+exp(theta_gamma))*VaR_t
es<- -abs(es)
num_llk<-QL(ret,VaR_t,tau)
den_llk<-tau*es

llk<-(tau-1)*(es)^-1*exp(num_llk/den_llk)

return(log(llk))

}



#' Asymmetric Slope estimation function
#'
#' Function for obtaining the Asymmetric Slope \insertCite{engle_manganelli_2004}{rqmidas} specification.
#' @param param Asymmetric Slope parameters to be estimated, that is: \eqn{\beta_0}, \eqn{\beta_1}, \eqn{\beta_2}, and \eqn{\beta_3}.
#' @param ret Daily returns.
#' @param alpha Quantile used.
#' @return The resulting vector represents the values of the Quantile Loss obtained from the Asymmetric Slope model.
#' @importFrom Rdpack reprompt
#' @keywords internal

as_fun <- function(param, ret, tau){

b0 <- param[1] 
b1 <- param[2] 
b2 <- param[3]
b3 <- param[4]

N<-length(ret)
VaR_t<- rep(NA,N); 
VaR_t[1] <- quantile(ret,tau)

ind_pos<-ifelse(ret>0,1,0)
ind_neg<-ifelse(ret<0,1,0)

    for(i in 2:N) {
      VaR_t[i] <- b0 + b1 * VaR_t[i-1] + (
		b2*ind_pos[i-1] + b3*ind_neg[i-1]
		)*abs(ret[i-1])
    }


    est<- -QL(ret,VaR_t,tau)
    #est<- mean(est)
    est
  }


#' Asymmetric Slope estimation function to obtain the Value-at-Risk
#'
#' Function for obtaining the Value-at-Risk from the the Asymmetric Slope \insertCite{engle_manganelli_2004}{rqmidas} specification.
#' @param param Asymmetric Slope parameters estimated, that is: \eqn{\beta_0}, \eqn{\beta_1}, \eqn{\beta_2}, and \eqn{\beta_3}.
#' @param ret Daily returns.
#' @param alpha Quantile used.
#' @return The resulting vector represents the values of the Value-at-Risk from the Asymmetric Slope model.
#' @importFrom Rdpack reprompt
#' @keywords internal

as_var <- function(param, ret, tau){

b0 <- param[1] 
b1 <- param[2] 
b2 <- param[3]
b3 <- param[4]

N<-length(ret)
VaR_t<- rep(NA,N)
VaR_t[1] <- quantile(ret,tau)

ind_pos<-ifelse(ret>0,1,0)
ind_neg<-ifelse(ret<0,1,0)

    for(i in 2:N) {
      VaR_t[i] <- b0 + b1 * VaR_t[i-1] + (
		b2*ind_pos[i-1] + b3*ind_neg[i-1]
		)*abs(ret[i-1])
    }


   return(VaR_t)

  }

#' Asymmetric Slope with Double Asymmetric MIDAS terms estimation function
#'
#' Function for obtaining the Asymmetric Slope \insertCite{engle_manganelli_2004}{rqmidas} specification.
#' @param param Asymmetric Slope parameters to be estimated, that is: \eqn{\beta_0}, \eqn{\beta_1}, \eqn{\beta_2}, and \eqn{\beta_3}.
#' @param ret Daily returns.
#' @param alpha Quantile used.
#' @return The resulting vector represents the values of the Quantile Loss obtained from the Asymmetric Slope model.
#' @importFrom Rdpack reprompt
#' @keywords internal

as_da_midas_fun <- function(param, ret, mv_m, K, tau){

b0 <- param[1] 
b1 <- param[2] 
b2 <- param[3]
b3 <- param[4]
theta_p <- param[5] 
w1<-1
w2_p <- param[6]  
theta_n <- param[7] 
w2_n <- param[8]  

N<-length(ret)
VaR_t<- rep(NA,N)
VaR_t[1] <- quantile(ret, p = tau)

ind_pos<-ifelse(ret>0,1,0)
ind_neg<-ifelse(ret<0,1,0)

mv_m_p<-ifelse(mv_m>=0,mv_m,0)
mv_m_n<-ifelse(mv_m<0,mv_m,0)

betas_p<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_p))[2:(K+1)],0)
tau_d_p<- suppressWarnings(roll::roll_sum(mv_m_p, c(K+1),weights = betas_p))
tau_d_p<-tau_d_p[(K+1),]	 

betas_n<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_n))[2:(K+1)],0)
tau_d_n<- suppressWarnings(roll::roll_sum(mv_m_n, c(K+1),weights = betas_n))
tau_d_n<-tau_d_n[(K+1),]	 


    for(i in 2:N) {
      VaR_t[i] <- b0 + b1 * VaR_t[i-1] + (
		b2*ind_pos[i-1] + b3*ind_neg[i-1]
		)*abs(ret[i-1]) + theta_p*tau_d_p[i-1]+
			theta_n*tau_d_n[i-1]  

    }


    est<- -QL(ret,VaR_t,tau)
    #est<- mean(est)
    est
  }

#' Asymmetric Slope with Double Asymmetric MIDAS terms function to obtain the Value-at-Risk
#'
#' Function for obtaining the Asymmetric Slope \insertCite{engle_manganelli_2004}{rqmidas} specification.
#' @param param Asymmetric Slope parameters to be estimated, that is: \eqn{\beta_0}, \eqn{\beta_1}, \eqn{\beta_2}, and \eqn{\beta_3}.
#' @param ret Daily returns.
#' @param alpha Quantile used.
#' @return The resulting vector represents the values of the Quantile Loss obtained from the Asymmetric Slope model.
#' @importFrom Rdpack reprompt
#' @keywords internal

as_da_midas_var <- function(param, ret, mv_m, K, tau){

b0 <- param[1] 
b1 <- param[2] 
b2 <- param[3]
b3 <- param[4]
theta_p <- param[5] 
w1<-1
w2_p <- param[6]  
theta_n <- param[7] 
w2_n <- param[8]  

N<-length(ret)
VaR_t<- rep(NA,N) 
VaR_t[1] <- quantile(ret, p = tau)

ind_pos<-ifelse(ret>0,1,0)
ind_neg<-ifelse(ret<0,1,0)


mv_m_p<-ifelse(mv_m>=0,mv_m,0)
mv_m_n<-ifelse(mv_m<0,mv_m,0)

betas_p<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_p))[2:(K+1)],0)
tau_d_p<- suppressWarnings(roll::roll_sum(mv_m_p, c(K+1),weights = betas_p))
tau_d_p<-tau_d_p[(K+1),]	 

betas_n<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_n))[2:(K+1)],0)
tau_d_n<- suppressWarnings(roll::roll_sum(mv_m_n, c(K+1),weights = betas_n))
tau_d_n<-tau_d_n[(K+1),]	 


    for(i in 2:N) {
      VaR_t[i] <- b0 + b1 * VaR_t[i-1] + (
		b2*ind_pos[i-1] + b3*ind_neg[i-1]
		)*abs(ret[i-1]) + theta_p*tau_d_p[i-1]+
			theta_n*tau_d_n[i-1]  

    }


    return(VaR_t)

  }


#' Asymmetric Slope estimation function via ALD with ES
#'
#' Function for obtaining the Asymmetric Slope \insertCite{engle_manganelli_2004}{rqmidas} specification.
#' @param param Asymmetric Slope parameters to be estimated, that is: \eqn{\beta_0}, \eqn{\beta_1}, \eqn{\beta_2}, and \eqn{\beta_3}.
#' @param ret Daily returns.
#' @param alpha Quantile used.
#' @return The resulting vector represents the values of the Quantile Loss obtained from the Asymmetric Slope model.
#' @importFrom Rdpack reprompt
#' @keywords internal

as_fun_es <- function(param, ret, tau){

b0 <- param[1] 
b1 <- param[2] 
b2 <- param[3]
b3 <- param[4]
theta_gamma<-param[5]

N<-length(ret)
VaR_t<- rep(NA,N) 
VaR_t[1] <- quantile(ret,tau)

ind_pos<-ifelse(ret>0,1,0)
ind_neg<-ifelse(ret<0,1,0)

    for(i in 2:N) {
      VaR_t[i] <- b0 + b1 * VaR_t[i-1] + (
		b2*ind_pos[i-1] + b3*ind_neg[i-1]
		)*abs(ret[i-1])
    }

es<-(1+exp(theta_gamma))*VaR_t
es<- -abs(es)
num_llk<-QL(ret,VaR_t,tau)
den_llk<-tau*es

llk<-(tau-1)*(es)^-1*exp(num_llk/den_llk)

return(log(llk))
  
}

#' Methods for estimating the CAViaR models
#'
#' Function for estimating several quantile regression based models
#' @param model Model to estimate. Valid choices are: "SAV" for Symmetric Absolute Value, "AS" for Asymmetric Slope, 
#' "IG" for Indirect GARCH, and "SAV_A_MIDAS" for the Symmetric Absolute Value with the double asymmetric MIDAS terms,
#' "IG_A_MIDAS" for the Indirect GARCH with the double asymmetric MIDAS terms and "AS_A_MIDAS" for the Asymmetric Slope 
#' with the double asymmetric MIDAS terms
#' @param tau The quantile to be estimated, this is a number strictly between 0 and 1
#' @param daily_ret Daily returns, which must be an "xts" object
#' @param mv_m **optional**. MIDAS variable already transformed into a matrix, through \code{\link[rumidas]{mv_into_mat}} function
#' @param K **optional**. Number of (lagged) realizations of the MIDAS variable to consider
#' @param out_of_sample **optional**. A positive integer indicating the number of periods before the last to keep for out of sample forecasting.
#' @param std_err **optional**. Type of standard errors computed. By default, the standard errors are
#' obtained by bootstrapping the residuals
#' @param B **optional**. Number of bootstrap replicates for obtaining the standard errors. 100 by default
#' @param R **optional**.  A positive integer indicating the number of replications used to find the best starting values. 
#' Equal to 100 by default
#' @param ES **optional**. If 'Yes', the model estimates also the Expected Shortfall via Asymmetric Laplace Distribution, as in \insertCite{taylor2019forecasting;textual}{rqmidas}.
#' Default to 'No'
#' @return \code{ucaviarfit} returns an object of class "rqmidas". The function \code{\link{summary.rqmidas}} 
#' can be used to print a summary of the results. Moreover, an object of class "rqmidas" is a list containing the following components:
#' \itemize{
#' 	\item model: The model used for the estimation.
#'   \item coef_mat: The matrix of estimated coefficients. 
#'   \item obs: The number of daily observations used for the (in-sample) estimation.
#'   \item period: The period of the in-sample estimation.
#'   \item VaR: The VaR measures of the in-sample period.
#'   \item ES: The ES measures of the in-sample period (if present).
#'	\item hit_in_s: The in-sample number of VaR violations.
#'	\item loss_in_s: The in-sample Quantile Loss average.
#'   \item VaR_oos: The VaR measures of the out-of-sample period (if present).
#'   \item ES_oos: The ES measures of the out-of-sample period (if present).
#'	\item hit_oos: The out-of-sample number of VaR violations (if present).
#'	\item loss_oos: The out-of-sample Quantile Loss average (if present).
#' }
#' @importFrom Rdpack reprompt
#' @importFrom stats optim
#' @import maxLik
#' @import lfda
#' @examples
#'
#' # estimate a Indirect GARCH model
#' r_t<-sp500['/2008']
#' fit<-ucaviarfit(model="IG",tau=0.05,daily_ret=r_t,R=10)
#' fit
#' summary.rqmidas(fit)
#' @export

ucaviarfit<-function(
model,
tau,
daily_ret,
mv_m=NULL,
K=NULL,
out_of_sample=NULL,
std_err="bootstrap",
B=100,
R=100,
ES='No'){

############################# check on valid choices
if(tau<0|tau>1) { stop(cat("#Warning:\n Parameter 'tau' must be a number strictly included between 0 and 1 \n"))}

if((model != "SAV")&(model != "SAV_A_MIDAS")&(model != "IG")&(model != "IG_A_MIDAS")&(model != "AS")
&(model != "AS_A_MIDAS")) { stop(cat("#Warning:\n Valid choices for the parameter 'model' 
are currently 'SAV', 'SAV_A_MIDAS', 'AS', 'AS_A_MIDAS', 'IG', and 'IG_A_MIDAS' \n"))}

N<-length(daily_ret)

VaR_oos<-NA
ES_oos<-NA

if (missing(out_of_sample)){ # out_of_sample parameter is missing

r_t_in_s<-daily_ret
r_t_in_s_est<-zoo::coredata(daily_ret)
mv_m_in_s<-mv_m



} else {					# out_of_sample parameter is present

r_t_in_s<-daily_ret[1:(N-out_of_sample)]
r_t_in_s_est<-zoo::coredata(r_t_in_s)

mv_m_in_s<-mv_m[,1:(N-out_of_sample)]

r_t_oos<-daily_ret[(N-out_of_sample+1):N]
mv_m_oos<-mv_m[,(N-out_of_sample+1):N]

N<-length(r_t_in_s)

}


############################################### Estimation

if (model=="SAV"&ES=="No"){

begin_val<-matrix(runif(R*3),ncol=3)
colnames(begin_val)<-c("beta_0","beta_1","beta_2")
which_row<-rep(NA,R)

for(i in 1:nrow(begin_val)){
which_row[i]<-mean(sav_fun(begin_val[i,],r_t_in_s_est,tau))
}

est<-suppressWarnings(maxLik(
logLik=sav_fun,
start=begin_val[which.max(which_row),],
ret=r_t_in_s_est,
tau=tau,
method="NM"))

VaR_est <- sav_var(stats::coef(est),r_t_in_s_est,tau)

if (!missing(out_of_sample)) {
VaR_oos <- sav_var(stats::coef(est),r_t_oos,tau)
VaR_oos <- xts::as.xts(VaR_oos,stats::time(r_t_oos))
}

} else if (model=="SAV"&ES=="Yes"){

begin_val<-matrix(runif(R*3),ncol=3)
colnames(begin_val)<-c("beta_0","beta_1","beta_2")
which_row<-rep(NA,R)

for(i in 1:nrow(begin_val)){
which_row[i]<-mean(sav_fun(begin_val[i,],r_t_in_s_est,tau))
}

est_0<-suppressWarnings(maxLik(
logLik=sav_fun,
start=begin_val[which.max(which_row),],
ret=r_t_in_s_est,
tau=tau,
method="BFGS"))

max_start_value<-matrix(NA,ncol=4,nrow=R)
sim_llk<-rep(NA,R)

for(i in 1:R){
max_start_value[i,]<-c(stats::coef(est_0),runif(1,-1,1))
sim_llk[i]<-mean(sav_fun_es(max_start_value[i,],r_t_in_s_est,tau))
}

start_val<-max_start_value[which.max(sim_llk),]

names(start_val)<-c("beta_0","beta_1","beta_2","gamma")

est<- maxLik(sav_fun_es, 
start=start_val, 
ret=r_t_in_s_est,
tau=tau,
method="BFGS")

VaR_est <- sav_var(stats::coef(est)[1:3],r_t_in_s_est,tau)
ES_est <- (1+exp(stats::coef(est)[4]))*VaR_est

if (!missing(out_of_sample)) {
VaR_oos <- sav_var(stats::coef(est)[1:3],r_t_oos,tau)
VaR_oos <- xts::as.xts(VaR_oos,stats::time(r_t_oos))
ES_oos <- (1+exp(stats::coef(est)[4]))*VaR_oos
}


} else if (model=="SAV_A_MIDAS"&ES=="No"){

ui<-ci<-NULL

ui<-rbind(
c(0,0,0,0,1,0,0),				 	## w2_pos > 1.001
c(0,0,0,0,0,0,1))					## w2_pos > 1.001

ci<-c(-1.001,-1.001)


begin_val<-matrix(runif(R*7,min=-1,max=1),ncol=7)
begin_val[,c(5,7)]<-1.1
colnames(begin_val)<-c("beta_0","beta_1","beta_2","theta_plus","omega_2_plus","theta_minus","omega_2_minus")
which_row<-rep(NA,R)

for(i in 1:nrow(begin_val)){
which_row[i]<-mean(sav_da_midas_fun(begin_val[i,],r_t_in_s_est,mv_m_in_s,K,tau))
}

est<- suppressWarnings(maxLik(
logLik=sav_da_midas_fun,
start=begin_val[which.max(which_row),],
ret=r_t_in_s_est,
mv_m=mv_m_in_s, 
K=K,
tau=tau,
constraints=list(ineqA=ui, ineqB=ci),
iterlim=1000,
method="BFGS"))

VaR_est <- sav_da_midas_var(stats::coef(est),r_t_in_s_est,mv_m=mv_m_in_s,K=K,tau=tau)

} else if (model=="SAV_A_MIDAS"&ES=="Yes"){

ui<-ci<-NULL

ui<-rbind(
c(0,0,0,0,1,0,0,0),				 	## w2_pos > 1.001
c(0,0,0,0,0,0,1,0))					## w2_neg > 1.001

ci<-c(-1.001,-1.001)


begin_val<-matrix(runif(R*7,min=-1,max=1),ncol=7)
begin_val[,c(5,7)]<-1.1
colnames(begin_val)<-c("beta_0","beta_1","beta_2","theta_plus","omega_2_plus","theta_minus","omega_2_minus")
which_row<-rep(NA,R)

for(i in 1:nrow(begin_val)){
which_row[i]<-mean(sav_da_midas_fun(begin_val[i,],r_t_in_s_est,mv_m_in_s,K,tau))
}

start_val<-c(begin_val[which.max(which_row),],0)

names(start_val)[length(start_val)]<-"theta_gamma"

est<- suppressWarnings(maxLik(
logLik=sav_da_midas_fun_es,
start=start_val,
ret=r_t_in_s_est,
mv_m=mv_m_in_s, 
K=K,
tau=tau,
constraints=list(ineqA=ui, ineqB=ci),
iterlim=1000,
method="BFGS"))

VaR_est <- sav_da_midas_var(stats::coef(est)[1:7],r_t_in_s_est,mv_m=mv_m_in_s,K=K,tau=tau)
ES_est <- (1+exp(stats::coef(est)[8]))*VaR_est

if (!missing(out_of_sample)) {
VaR_oos <- sav_da_midas_var(stats::coef(est)[1:7],r_t_oos,mv_m=mv_m_oos,K=K,tau)
VaR_oos <- xts::as.xts(VaR_oos,stats::time(r_t_oos))
ES_oos <- (1+exp(stats::coef(est)[8]))*VaR_oos
}

} else if (model=="AS"&ES=="No"){

begin_val<-matrix(runif(R*4),ncol=4)
colnames(begin_val)<-c("beta_0","beta_1","beta_2","beta_3")
which_row<-rep(NA,R)

for(i in 1:nrow(begin_val)){
which_row[i]<-mean(as_fun(begin_val[i,],r_t_in_s_est,tau))
}

est<- suppressWarnings(maxLik(
logLik=as_fun,
start=begin_val[which.max(which_row),],
ret=r_t_in_s_est,
tau=tau,
method="NM"))

VaR_est <- as_var(stats::coef(est),r_t_in_s_est,tau)

if (!missing(out_of_sample)) {
VaR_oos <- as_var(stats::coef(est),r_t_oos,tau)
VaR_oos <- xts::as.xts(VaR_oos,stats::time(r_t_oos))
}

} else if (model=="AS"&ES=="Yes"){

begin_val<-matrix(runif(R*4),ncol=4)
colnames(begin_val)<-c("beta_0","beta_1","beta_2","beta_3")
which_row<-rep(NA,R)

for(i in 1:nrow(begin_val)){
which_row[i]<-mean(as_fun(begin_val[i,],r_t_in_s_est,tau))
}

est_0<- suppressWarnings(maxLik(
logLik=as_fun,
start=begin_val[which.max(which_row),],
ret=r_t_in_s_est,
tau=tau,
method="NM"))

max_start_value<-matrix(NA,ncol=5,nrow=R)
sim_llk<-rep(NA,R)

for(i in 1:R){
max_start_value[i,]<-c(stats::coef(est_0),runif(1,-1,1))
sim_llk[i]<-mean(as_fun_es(max_start_value[i,],r_t_in_s_est,tau))
}

start_val<-max_start_value[which.max(sim_llk),]

names(start_val)<-c("beta_0","beta_1","beta_2","beta_3","gamma")

est<- maxLik(as_fun_es, 
start=start_val, 
ret=r_t_in_s_est,
tau=tau,
method="BFGS")

VaR_est <- as_var(stats::coef(est)[1:4],r_t_in_s_est,tau)
ES_est <- (1+exp(stats::coef(est)[5]))*VaR_est

if (!missing(out_of_sample)) {
VaR_oos <- as_var(stats::coef(est)[1:4],r_t_oos,tau)
VaR_oos <- xts::as.xts(VaR_oos,stats::time(r_t_oos))
ES_oos <- (1+exp(stats::coef(est)[5]))*VaR_oos
}


} else if (model=="AS_A_MIDAS"&ES=="No"){

ui<-ci<-NULL

ui<-rbind(
c(0,0,0,0,0,1,0,0),				 	## w2_pos > 1.001
c(0,0,0,0,0,0,0,1))					## w2_pos > 1.001

ci<-c(-1.001,-1.001)


begin_val<-matrix(runif(R*8,min=-1,max=1),ncol=8)
begin_val[,c(6,8)]<-1.1
colnames(begin_val)<-c("beta_0","beta_1","beta_2","beta_3","theta_plus","omega_2_plus","theta_minus","omega_2_minus")
which_row<-rep(NA,R)

for(i in 1:nrow(begin_val)){
which_row[i]<-mean(as_da_midas_fun(begin_val[i,],r_t_in_s_est,mv_m_in_s,K,tau))
}

est<- suppressWarnings(maxLik(
logLik=as_da_midas_fun,
start=begin_val[which.max(which_row),],
ret=r_t_in_s_est,
mv_m=mv_m_in_s, 
K=K,
tau=tau,
constraints=list(ineqA=ui, ineqB=ci),
iterlim=1000,
method="BFGS"))

VaR_est <- as_da_midas_var(stats::coef(est),r_t_in_s_est,mv_m=mv_m_in_s,K=K,tau=tau)

} else if (model=="IG"&ES=="No"){

begin_val<-matrix(runif(R*3),ncol=3)
colnames(begin_val)<-c("beta_0","beta_1","beta_2")
which_row<-rep(NA,R)

for(i in 1:nrow(begin_val)){
which_row[i]<-mean(ig_fun(begin_val[i,],r_t_in_s_est,tau))
}

est<- suppressWarnings(maxLik(
logLik=ig_fun,
start=begin_val[which.max(which_row),],
ret=r_t_in_s_est,
tau=tau,
method="NM"))

VaR_est <- ig_var(stats::coef(est),r_t_in_s_est,tau)

if (!missing(out_of_sample)) {
VaR_oos <- ig_var(stats::coef(est),r_t_oos,tau)
VaR_oos <- xts::as.xts(VaR_oos,stats::time(r_t_oos))
}

} else if (model=="IG"&ES=="Yes"){

begin_val<-matrix(runif(R*3),ncol=3)
colnames(begin_val)<-c("beta_1","beta_2","beta_3")
which_row<-rep(NA,R)

for(i in 1:nrow(begin_val)){
which_row[i]<-mean(ig_fun(begin_val[i,],r_t_in_s_est,tau))
}

est_0<- suppressWarnings(maxLik(
logLik=ig_fun,
start=begin_val[which.max(which_row),],
ret=r_t_in_s_est,
tau=tau,
method="NM"))

max_start_value<-matrix(NA,ncol=4,nrow=R)
sim_llk<-rep(NA,R)

for(i in 1:R){
max_start_value[i,]<-c(stats::coef(est_0),runif(1,-1,1))
sim_llk[i]<-mean(ig_fun_es(max_start_value[i,],r_t_in_s_est,tau))
}

start_val<-max_start_value[which.max(sim_llk),]

names(start_val)<-c("beta_1","beta_2","beta_3","gamma")

est<- maxLik(ig_fun_es, 
start=start_val, 
ret=r_t_in_s_est,
tau=tau,
method="BFGS")

VaR_est <- ig_var(stats::coef(est)[1:3],r_t_in_s_est,tau)
ES_est <- (1+exp(stats::coef(est)[4]))*VaR_est

if (!missing(out_of_sample)) {
VaR_oos <- ig_var(stats::coef(est)[1:3],r_t_oos,tau)
VaR_oos <- xts::as.xts(VaR_oos,stats::time(r_t_oos))
ES_oos <- (1+exp(stats::coef(est)[4]))*VaR_oos
}

} else if (model=="IG_A_MIDAS"&ES=="No"){

ui<-ci<-NULL

ui<-rbind(
c(0,0,0,0,1,0,0),				 	## w2_pos > 1.001
c(0,0,0,0,0,0,1))					## w2_pos > 1.001

ci<-c(-1.001,-1.001)

begin_val<-matrix(runif(R*7,min=0,max=1),ncol=7)
begin_val[,c(5,7)]<-1.1
colnames(begin_val)<-c("beta_0","beta_1","beta_2","theta_plus","omega_2_plus","theta_minus","omega_2_minus")
which_row<-rep(NA,R)

for(i in 1:nrow(begin_val)){
which_row[i]<-mean(ig_da_midas_fun(begin_val[i,],r_t_in_s_est,mv_m_in_s,K,tau))
}

est<- suppressWarnings(maxLik(
logLik=ig_da_midas_fun,
start=begin_val[which.max(which_row),],
ret=r_t_in_s_est,
mv_m=mv_m_in_s, 
K=K,
tau=tau,
constraints=list(ineqA=ui, ineqB=ci),
iterlim=1000,
method="BFGS"))

VaR_est <- ig_da_midas_var(stats::coef(est),r_t_in_s_est,mv_m=mv_m_in_s,K=K,tau=tau)

}


N_coef<-length(stats::coef(est))

# residuals

res<-r_t_in_s_est-VaR_est
stand_res<-(r_t_in_s_est-VaR_est)/abs(VaR_est)

N_est<-length(res)
mat_coef<-data.frame(rep(NA,N_coef),rep(NA,N_coef),rep(NA,N_coef),rep(NA,N_coef))
colnames(mat_coef)<-c("Estimate","Std. Error","t value","Pr(>|t|)")
rownames(mat_coef)<-names(stats::coef(est))

#### var-cov-matrix

if (std_err!="bootstrap"){
k_t_hat<-stats::mad(res)
m_t_hat<-quantreg::bandwidth.rq(tau,N_est)
c_t_hat<-k_t_hat*(qnorm(tau+m_t_hat)-qnorm(tau-m_t_hat))

GR<-est$gradientObs

A_T_hat<-N_est^-1*(tau)*(1-tau)*t(GR)%*%GR
IND<-ifelse(abs(r_t_in_s_est-VaR_est)<c_t_hat,1,0)
D_T_hat<-(2*N_est*c_t_hat)^(-1)*sum(IND*rowSums(GR^2))

sd_est<-(diag((N_est^0.5*A_T_hat%^%(-1/2)*D_T_hat))^-1)

} else { ## bootstrap standard errors

mat_boot_results<-matrix(rep(NA),nrow=B,ncol=N_coef)

pb <- utils::txtProgressBar(0, B, style = 3)

for(b in 1:B){

##### first step: compute the boostrapped series of residuals

res_boot<-sample(stand_res,N_est,replace=T)

##### second step: compute the bootstraped series of returns and VaRs

r_t_boot<-r_t_in_s_est
VaR_boot<-VaR_est

if(model=="SAV"&ES=="No"){ ############################################# model SAV

b0<-stats::coef(est)[1]
b1<-stats::coef(est)[2]
b2<-stats::coef(est)[3]

for(i in 2:N_est){
VaR_boot[i]<-b0 + b1 * VaR_boot[i-1]  + b2*abs(r_t_boot[i-1])
r_t_boot[i]<-VaR_boot[i]+abs(VaR_boot[i])*res_boot[i]
}

est_boot<- suppressWarnings(maxLik(
logLik=sav_fun,
start=stats::coef(est),
ret=r_t_boot,
tau=tau,
method="NM"))

} else if (model=="SAV"&ES=="Yes"){ ############################################# model SAV + ES

b0<-stats::coef(est)[1]
b1<-stats::coef(est)[2]
b2<-stats::coef(est)[3]

for(i in 2:N_est){
VaR_boot[i]<-b0 + b1 * VaR_boot[i-1]  + b2*abs(r_t_boot[i-1])
r_t_boot[i]<-VaR_boot[i]+abs(VaR_boot[i])*res_boot[i]
}

est_boot<- suppressWarnings(maxLik(
logLik=sav_fun_es,
start=stats::coef(est),
ret=r_t_boot,
tau=tau,
method="NM"))

} else if (model=="SAV_A_MIDAS"&ES=="No"){ ############################################# model SAV-A-MIDAS

b0 <- stats::coef(est)[1] 
b1 <- stats::coef(est)[2] 
b2 <- stats::coef(est)[3]
theta_p <- stats::coef(est)[4] 
w1<-1
w2_p <- stats::coef(est)[5]  
theta_n <- stats::coef(est)[6] 
w2_n <- stats::coef(est)[7]

mv_m_p<-ifelse(mv_m_in_s>=0,mv_m_in_s,0)

mv_m_n<-ifelse(mv_m_in_s<0,mv_m_in_s,0)

betas_p<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_p))[2:(K+1)],0)
tau_d_p<- suppressWarnings(roll::roll_sum(mv_m_p, c(K+1),weights = betas_p))
tau_d_p<-tau_d_p[(K+1),]         

betas_n<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_n))[2:(K+1)],0)
tau_d_n<- suppressWarnings(roll::roll_sum(mv_m_n, c(K+1),weights = betas_n))
tau_d_n<-tau_d_n[(K+1),]         

for(i in 2:N_est) {
VaR_boot[i] <- b0 + b1 * VaR_boot[i-1]  + b2*abs(r_t_boot[i-1]) + theta_p*tau_d_p[i-1]+
                        theta_n*tau_d_n[i-1]  
r_t_boot[i]<-VaR_boot[i]+abs(VaR_boot[i])*res_boot[i]
}


ui<-ci<-NULL

ui<-rbind(
c(0,0,0,0,1,0,0),				 	## w2_pos > 1.001
c(0,0,0,0,0,0,1))					## w2_pos > 1.001

ci<-c(-1.001,-1.001)

est_boot<- suppressWarnings(maxLik(
logLik=sav_da_midas_fun,
start=stats::coef(est),
ret=r_t_boot,
mv_m=mv_m_in_s, 
K=K,
tau=tau,
constraints=list(ineqA=ui, ineqB=ci),
iterlim=1000,
method="BFGS"))


} else if(model=="AS"&ES=="No"){ ############################################# model AS

b0<-stats::coef(est)[1]
b1<-stats::coef(est)[2]
b2<-stats::coef(est)[3]
b3<-stats::coef(est)[4]

for(i in 2:N_est){

ind_pos<-ifelse(r_t_boot[i-1]>0,1,0)
ind_neg<-ifelse(r_t_boot[i-1]<0,1,0)

VaR_boot[i]<- b0 + b1 * VaR_boot[i-1] + (
                b2*ind_pos + b3*ind_neg
                )*abs(r_t_boot[i-1])
r_t_boot[i]<-VaR_boot[i]+abs(VaR_boot[i])*res_boot[i]
}

est_boot<- suppressWarnings(maxLik(
logLik=as_fun,
start=stats::coef(est),
ret=r_t_boot,
tau=tau,
method="NM"))

} else if(model=="AS"&ES=="Yes"){ ############################################# model AS

b0<-stats::coef(est)[1]
b1<-stats::coef(est)[2]
b2<-stats::coef(est)[3]
b3<-stats::coef(est)[4]

for(i in 2:N_est){

ind_pos<-ifelse(r_t_boot[i-1]>0,1,0)
ind_neg<-ifelse(r_t_boot[i-1]<0,1,0)

VaR_boot[i]<- b0 + b1 * VaR_boot[i-1] + (
                b2*ind_pos + b3*ind_neg
                )*abs(r_t_boot[i-1])
r_t_boot[i]<-VaR_boot[i]+abs(VaR_boot[i])*res_boot[i]
}

est_boot<- suppressWarnings(maxLik(
logLik=as_fun_es,
start=stats::coef(est),
ret=r_t_boot,
tau=tau,
method="BFGS"))

} else if (model=="AS_A_MIDAS"){ ############################################# model AS-A-MIDAS

b0 <- stats::coef(est)[1] 
b1 <- stats::coef(est)[2] 
b2 <- stats::coef(est)[3]
b3 <- stats::coef(est)[4]
theta_p <- stats::coef(est)[5] 
w1<-1
w2_p <- stats::coef(est)[6]  
theta_n <- stats::coef(est)[7] 
w2_n <- stats::coef(est)[8]

mv_m_p<-ifelse(mv_m_in_s>=0,mv_m_in_s,0)
mv_m_n<-ifelse(mv_m_in_s<0,mv_m_in_s,0)

betas_p<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_p))[2:(K+1)],0)
tau_d_p<- suppressWarnings(roll::roll_sum(mv_m_p, c(K+1),weights = betas_p))
tau_d_p<-tau_d_p[(K+1),]         

betas_n<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_n))[2:(K+1)],0)
tau_d_n<- suppressWarnings(roll::roll_sum(mv_m_n, c(K+1),weights = betas_n))
tau_d_n<-tau_d_n[(K+1),]   


for(i in 2:N_est) {

ind_pos<-ifelse(r_t_boot[i-1]>0,1,0)
ind_neg<-ifelse(r_t_boot[i-1]<0,1,0) 

VaR_boot[i] <- b0 + b1 * VaR_boot[i-1] + (
                b2*ind_pos + b3*ind_neg
                )*abs(r_t_boot[i-1]) + theta_p*tau_d_p[i-1]+
                        theta_n*tau_d_n[i-1]
  
r_t_boot[i]<-VaR_boot[i]+abs(VaR_boot[i])*res_boot[i]

}


ui<-ci<-NULL

ui<-rbind(
c(0,0,0,0,0,1,0,0),				 	## w2_pos > 1.001
c(0,0,0,0,0,0,0,1))					## w2_pos > 1.001

ci<-c(-1.001,-1.001)

est_boot<- suppressWarnings(maxLik(
logLik=as_da_midas_fun,
start=stats::coef(est),
ret=r_t_boot,
mv_m=mv_m_in_s, 
K=K,
tau=tau,
constraints=list(ineqA=ui, ineqB=ci),
iterlim=1000,
method="BFGS"))


} else if(model=="IG"){ ############################################# model IG

b1<-stats::coef(est)[1]
b2<-stats::coef(est)[2]
b3<-stats::coef(est)[3]

for(i in 2:N_est){
VaR_boot[i]<-c(- (b1 + b2 * VaR_boot[i-1]^2 + b3 * r_t_boot[i-1]^2)^(0.5))
r_t_boot[i]<-VaR_boot[i]+abs(VaR_boot[i])*res_boot[i]
}

est_boot<- suppressWarnings(maxLik(
logLik=ig_fun,
start=stats::coef(est),
ret=r_t_boot,
tau=tau,
method="NM"))

} else if (model=="IG_A_MIDAS"){ ############################################# model IG-A-MIDAS

b1 <- stats::coef(est)[1] 
b2 <- stats::coef(est)[2] 
b3 <- stats::coef(est)[3]
theta_p <- stats::coef(est)[4] 
w1<-1
w2_p <- stats::coef(est)[5]  
theta_n <- stats::coef(est)[6] 
w2_n <- stats::coef(est)[7]

mv_m_p<-ifelse(mv_m_in_s>=0,mv_m_in_s,0)
mv_m_n<-ifelse(mv_m_in_s<0,mv_m_in_s,0)

betas_p<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_p))[2:(K+1)],0)
tau_d_p<- suppressWarnings(roll::roll_sum(mv_m_p, c(K+1),weights = betas_p))
tau_d_p<-tau_d_p[(K+1),]         

betas_n<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_n))[2:(K+1)],0)
tau_d_n<- suppressWarnings(roll::roll_sum(mv_m_n, c(K+1),weights = betas_n))
tau_d_n<-tau_d_n[(K+1),]   


for(i in 2:N_est) {

VaR_boot[i] <-  c(- (b1 + b2 * VaR_boot[i-1]^2 + b3 * r_t_boot[i-1]^2 + theta_p*tau_d_p[i-1]+
                        theta_n*tau_d_n[i-1]  )^(0.5))
 
r_t_boot[i]<-VaR_boot[i]+abs(VaR_boot[i])*res_boot[i]

}

ui<-ci<-NULL

ui<-rbind(
c(0,0,0,0,1,0,0),				 	## w2_pos > 1.001
c(0,0,0,0,0,0,1))					## w2_pos > 1.001

ci<-c(-1.001,-1.001)

est_boot<- suppressWarnings(maxLik(
logLik=ig_da_midas_fun,
start=stats::coef(est),
ret=r_t_boot,
mv_m=mv_m_in_s, 
K=K,
tau=tau,
constraints=list(ineqA=ui, ineqB=ci),
iterlim=1000,
method="BFGS"))

}


##### third step: compute the new estimates (based on bootstrapped returns)

mat_boot_results[b,]<-stats::coef(est_boot)

utils::setTxtProgressBar(pb, b)
}  

Sys.sleep(1)
close(pb)

## compute the standard errors 

sd_est<-apply(mat_boot_results,2,stats::sd)

}




mat_coef[,1]<-round(stats::coef(est),6)
mat_coef[,2]<-round(sd_est,6)
mat_coef[,3]<-round(stats::coef(est)/sd_est,6)
mat_coef[,4]<-round(apply(rbind(stats::coef(est)/sd_est),1,function(x) 2*(1-stats::pnorm(abs(x)))),6)


###

if (ES=="No"){
res_f<-list(
model=model,
coef_mat=round(mat_coef,5),
obs=N,
period=range(stats::time(r_t_in_s)),
VaR=xts::as.xts(VaR_est,stats::time(r_t_in_s)),
hit_in_s=sum(ifelse(r_t_in_s<=VaR_est,1,0))/N,
loss_in_s=QL(r_t_in_s,VaR_est,tau),
VaR_oos=VaR_oos
)} else {
res_f<-list(
model=model,
coef_mat=round(mat_coef,5),
obs=N,
period=range(stats::time(r_t_in_s)),
VaR=xts::as.xts(VaR_est,stats::time(r_t_in_s)),
ES=xts::as.xts(ES_est,stats::time(r_t_in_s)),
hit_in_s=sum(ifelse(r_t_in_s<=VaR_est,1,0))/N,
loss_in_s=QL(r_t_in_s,VaR_est,tau),
VaR_oos=VaR_oos,
ES_oos=ES_oos
)

}

class(res_f)<-c("rqmidas")

return(res_f)
print.rqmidas(res_f)


}



