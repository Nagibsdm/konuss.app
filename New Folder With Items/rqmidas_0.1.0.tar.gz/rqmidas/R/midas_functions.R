#' Linear ARCH via ALD with ES
#'
#' Function for obtaining the Linear ARCH specification.
#' @param param Linear ARCH parameters to be estimated, that is: \eqn{\beta_0}, \eqn{\beta_1}, ..., \eqn{\beta_q}.
#' @param ret Daily returns.
#' @param tau Quantile level used.
#' @return The resulting vector represents the values of the ALD log-likelihood obtained.
#' @importFrom Rdpack reprompt
#' @keywords internal

lARCH_fun_es <- function(param, ret, X_t, tau){

q<-ncol(X_t)-1

N<-length(ret)

VaR_t<- rep(NA,N)
VaR_t[1:q] <- quantile(ret,tau)

 for(i in (q+1):N) {
      VaR_t[i] <- X_t[i,]%*%cbind(param[1:(q+1)])
    }

es<-(1+exp(param[q+2]))*VaR_t
es<- -abs(es)
num_llk<-QL(ret,VaR_t,tau)
den_llk<-tau*es

llk<-(tau-1)*(es)^-1*exp(num_llk/den_llk)

return(log(llk)[(q+1):N])

}

#' Linear ARCH via ALD with ES (VaR)
#'
#' Function for obtaining the VaR measures for the Linear ARCH specification.
#' @param param Linear ARCH parameters to be estimated, that is: \eqn{\beta_0}, \eqn{\beta_1}, ..., \eqn{\beta_q}.
#' @param ret Daily returns.
#' @param tau Quantile level used.
#' @return The resulting vector represents the values of the ALD log-likelihood obtained.
#' @importFrom Rdpack reprompt
#' @keywords internal

lARCH_var_es <- function(param, ret, X_t, tau){

q<-ncol(X_t)-1

N<-length(ret)

VaR_t<- rep(NA,N)
VaR_t[1:q] <- quantile(ret,tau)

 for(i in (q+1):N) {
      VaR_t[i] <- X_t[i,]%*%cbind(param[1:(q+1)])
    }

return(VaR_t)

}

#' Methods for estimating (and evaluating) a variety of quantile regression based models
#'
#' Function for estimating several quantile regression based models
#' @param model Model to estimate. Valid choices are: "lARCH" for linear ARCH, "lARCHMIDAS" for linear ARCH-MIDAS, 
#' "lARCHX" for linear ARCH with the "X" component and "lARCHMIDASX" for linear ARCH-MIDAS with the "X" component.
#' @param tau The quantile to be estimated, this is a number strictly between 0 and 1
#' @param daily_ret Daily returns, which must be an "xts" object.
#' @param q Order of the daily lagged returns to include in the model. Must be a positive number.
#' @param ES **optional**. If "Yes", also the Expected Shortfall will be estimated. Default to "No".
#' @param mv_m **optional**. MIDAS variable already transformed into a matrix, through \code{\link[rumidas]{mv_into_mat}} function. NULL by default.
#' @param K **optional**. Number of (lagged) realizations of the MIDAS variable to consider.
#' @param X **optional**. The "X" component. It must be positive and an "xts" object.
#' @param out_of_sample **optional**. A positive integer indicating the number of periods before the last to keep for out of sample forecasting.
#' @param ... **optional**. Further arguments passed from the \code{\link[quantreg]{rq}} function.
#' @return \code{uqfit} returns an object of class "rqmidas". The function \code{\link{summary.rqmidas}} 
#' can be used to print a summary of the results. Moreover, an object of class "rqmidas" is a list containing the following components:
#' \itemize{
#' 	\item model: The model used for the estimation.
#'   \item coef_mat: The matrix of estimated coefficients. 
#'   \item obs: The number of daily observations used for the (in-sample) estimation.
#'   \item period: The period of the in-sample estimation.
#'   \item VaR: The VaR measures of the in-sample period.
#'   \item ES: The ES measures of the in-sample period (if present).
#'	\item hit_in_s: The in-sample number of VaR violations.
#'	\item loss_in_s: The in-sample Quantile Loss values.
#'   \item VaR_oos: The VaR measures of the out-of-sample period (if present).
#'   \item ES_oos: The ES measures of the out-of-sample period (if present).
#' }
#' @importFrom Rdpack reprompt
#' @importFrom stats time
#' @importFrom rumidas beta_function
#' @importFrom rumidas mv_into_mat
#' @importFrom zoo coredata
#' @import maxLik
#' 
#' @details
#' Function \code{uqfit} implements the estimation and evaluation of the several quantile regression based models, with the aim of obtaining the
#' Value-at-Risk (VaR) forecasts. The first model estimated is the linear ARCH of \insertCite{taylor1986}{rqmidas}, which is defined as: 
#' \deqn{r_{i,t} = (\beta_0 + \beta_1 |r_{i-1,t}| + \cdots + \beta_q |r_{i-q,t}|) z_{i,t},}
#' where 
#' \itemize{
#' \item \eqn{r_{i,t}} is the daily return for the \eqn{i}-th day (\eqn{i = 1, \ldots, N_t}) 
#' of the period \eqn{t} (for example, a week, a month or a quarter; \eqn{t = 1 , \ldots, T});
#' \item \eqn{z_{i,t}} is an \eqn{iid} error term which has a zero mean and unit variance.
#' }
#' The VaR at time \eqn{i,t} and at the \eqn{\tau}-th level, given the information set \eqn{\mathcal{F}_{i-i,t}}, is directly calculated as:
#' \deqn{\hat{Q}_{r_{i,t}}\left(\tau|\mathcal{F}_{i-1,t}\right)= \bm{x}_{i,t}^{'}\hat{\bm{\beta}}(\tau)},
#' where \eqn{\bm{x}_{i,t}=\left(1, |r_{i-1,t}|,\cdots,|r_{i-q,t}|\right)^{'}}.
#' The linear ARCH with the "X" component is:
#' \deqn{r_{i,t} = (\beta_0 + \beta_1 |r_{i-1,t}| + \cdots + \beta_q |r_{i-q,t}| + \beta_X |X_{i-1,t}|) z_{i,t}.}
#' The linear ARCH with the MIDAS component is:
#' \deqn{r_{i,t} = (\beta_0 + \beta_1 |r_{i-1,t}| + \cdots + \beta_q |r_{i-q,t}| + \theta \sum_{j=1}^K \delta_k(\omega)|MV_{t-j}|) z_{i,t},}
#' where  \eqn{\delta_k(\omega)} is the Beta function.
#' Finally, the linear ARCH with the MIDAS and X components is:
#' \deqn{r_{i,t} = (\beta_0 + \beta_1 |r_{i-1,t}| + \cdots + \beta_q |r_{i-q,t}| +\beta_X |X_{i-1,t}| +\theta \sum_{j=1}^K \delta_k(\omega)|MV_{t-j}|) z_{i,t}.}
#'
#' @examples
#'
#' # estimate the linear ARCH model using the quantile regression
#' r_t<-sp500['/2008']
#' fit<-uqfit(model="lARCH",tau=0.05,daily_ret=r_t,q=5)
#' fit
#' summary.rqmidas(fit)
#' 
#' # estimate the linear ARCH model with a MIDAS component (Industrial Production)
#' # using the quantile regression
#' mv_m<-mv_into_mat(r_t,diff(indpro),K=12,"monthly") 
#' fit_2<-uqfit(model="lARCHMIDAS",tau=0.05,daily_ret=r_t,mv_m=mv_m,K=12,q=5)
#' fit_2
#' summary.rqmidas(fit_2)
#' 
#' # estimate the linear ARCH model with a MIDAS and X components 
#' # using the quantile regression
#' fit_3<-uqfit(model="lARCHMIDASX",tau=0.05,daily_ret=r_t,mv_m=mv_m,K=12,q=5,X=rv5['/2008']^0.5)
#' fit_3
#' summary.rqmidas(fit_3)
#' @export

uqfit<-function(
model,
tau,
daily_ret,
q,
ES="No",
mv_m=NULL,
K=NULL,
X=NULL,
out_of_sample=NULL,
...){

############################# check on valid choices
if(tau<0|tau>1) { stop(cat("#Warning:\n Parameter 'tau' must be a number strictly included between 0 and 1 \n"))}
if((model != "lARCH")&(model != "lARCHX")&(model != "lARCHMIDAS")&(model != "lARCHMIDASX")) { stop(cat("#Warning:\n Valid choices for the parameter 'model' 
are currently 'lARCH', 'lARCHX', 'lARCHMIDAS', and 'lARCHMIDASX' \n"))}
if(missing(q)) { stop(cat("#Warning:\n Parameter 'q' must be provided \n"))}
if(q<1) { stop(cat("#Warning:\n Parameter 'q' must be positive \n"))}

N<-length(daily_ret)

cond_r_t<- class(daily_ret)[1]
cond_mv_m<- class(mv_m)[1]

if(cond_r_t != "xts") { stop(
cat("#Warning:\n Parameter 'daily_ret' must be an xts object. Please provide it in the correct form \n")
)}

if((model=="lARCHMIDAS"|model=="lARCHMIDASX")&cond_mv_m != "matrix") { stop(
cat("#Warning:\n Parameter 'mv_m' must be a matrix. Please provide it in the correct form \n")
)}

if((model=="lARCHX"|model=="lARCHMIDASX")& missing(X)) { stop(
cat("#Warning:\n Parameter 'X' must be provided. \n")
)}


if((model=="lARCHMIDAS"|model=="lARCHMIDASX")& missing(K)) { stop(
cat("#Warning:\n Parameter 'K' must be provided. \n")
)}


############## check if the X term is provided and if it has the same time span of daily_ret

if(!missing(X)){ 
if(any(range(time(daily_ret))!=range(time(X)))){
stop(
cat("#Warning:\n The vector 'X' has to be observed during the same time span of 'daily_ret' \n")
)}}

if (missing(out_of_sample)){ # out_of_sample parameter is missing

r_t_in_s<-daily_ret
mv_m_in_s<-mv_m
X_in_s<-X


} else {					# out_of_sample parameter is present

r_t_in_s<-daily_ret[1:(N-out_of_sample)]
mv_m_in_s<-mv_m[,1:(N-out_of_sample)]
X_in_s<-X[1:(N-out_of_sample)]

r_t_oos<-daily_ret[(N-out_of_sample+1):N]
mv_m_oos<-mv_m[,(N-out_of_sample+1):N]
X_oos<-X[(N-out_of_sample+1):N]

N<-length(r_t_in_s)

}



############################################### Estimation

if (model=="lARCH"&ES=="No"){
ES<-ES_oos<-NA
############################ construction of X_t matrix

X_t<-cbind(
rep(1,N),
stats::lag(abs(r_t_in_s),k=1:q)) 

X_t<-replace(X_t,is.na(X_t),0)

colnames(X_t)<-paste("beta","_",0:q,sep="")

## Est.

X_t<-zoo::coredata(cbind(X_t[,2:(q+1)]))
Y<-zoo::coredata(r_t_in_s)
MAT<-data.frame(Y,X_t)
colnames(MAT)[1]<-"Y_t"
res<-rq(formula = Y_t ~ ., tau = tau, data=MAT)

VaR<-stats::fitted.values(res)

if (!missing(out_of_sample)) {

N_full<-length(daily_ret)
X_t_full<-cbind(
stats::lag(abs(daily_ret),k=1:q)) 

X_t_full<-replace(X_t_full,is.na(X_t_full),0)
X_t_oos<-zoo::coredata(X_t_full[(N_full-out_of_sample+1):N_full,])
X_t_oos<-as.data.frame(X_t_oos)
colnames(X_t_oos)<-colnames(X_t)
VaR_oos<-stats::predict(res,newdata=X_t_oos)

}

} else if (model=="lARCH"&ES=="Yes"){
############################ construction of X_t matrix

X_t<-cbind(
rep(1,N),
stats::lag(abs(r_t_in_s),k=1:q)) 

X_t<-replace(X_t,is.na(X_t),0)

colnames(X_t)<-paste("beta","_",0:q,sep="")

## Est.

X_t<-zoo::coredata(cbind(X_t[,2:(q+1)]))
Y<-zoo::coredata(r_t_in_s)
MAT<-data.frame(Y,X_t)
colnames(MAT)[1]<-"Y_t"
res<-rq(formula = Y_t ~ ., tau = tau, data=MAT)

start_val<-c(stats::coef(res),0)

names(start_val)[(q+2)]<-"theta_gamma"

res<- maxLik(lARCH_fun_es, 
start=start_val, 
ret=zoo::coredata(r_t_in_s),
X_t=cbind(1,X_t),
tau=tau,
method="BFGS")

VaR<-lARCH_var_es(stats::coef(res)[1:(q+1)],
zoo::coredata(r_t_in_s),cbind(1,X_t),tau=tau)
ES<-(1+exp(stats::coef(res)[q+2]))*VaR
ES<-as.xts(ES,stats::time(r_t_in_s))

################################ oos

if (!missing(out_of_sample)) {

N_full<-length(daily_ret)
X_t_full<-cbind(
stats::lag(abs(daily_ret),k=1:q)) 

X_t_full<-replace(X_t_full,is.na(X_t_full),0)
X_t_oos<-zoo::coredata(X_t_full[(N_full-out_of_sample+1):N_full,])
X_t_oos<-as.matrix(X_t_oos)
colnames(X_t_oos)<-colnames(X_t)
VaR_oos<-lARCH_var_es(stats::coef(res)[1:(q+1)],
zoo::coredata(r_t_oos),cbind(1,X_t_oos),tau=tau)
ES_oos<-(1+exp(stats::coef(res)[q+2]))*VaR_oos
ES_oos<-as.xts(ES_oos,stats::time(r_t_oos))

}

} else if (model=="lARCHX"&ES=="No"){
ES<-ES_oos<-NA
############################ construction of X_t matrix

X_t<-cbind(
rep(1,N),
stats::lag(abs(r_t_in_s),k=1:q),
stats::lag(abs(X_in_s),k=1)) 

X_t<-replace(X_t,is.na(X_t),0)

colnames(X_t)[1:(q+1)]<-paste("beta","_",0:q,sep="")
colnames(X_t)[(q+2)]<-paste("beta","_","X",sep="")

## Est.

X_t<-zoo::coredata(cbind(X_t[,2:(q+2)]))
Y<-zoo::coredata(r_t_in_s)
MAT<-data.frame(Y,X_t)
colnames(MAT)[1]<-"Y_t"

res<-rq(formula = Y_t ~ ., tau = tau, data=MAT)

VaR<-stats::fitted.values(res)

################################ oos

if (!missing(out_of_sample)) {

N_full<-length(daily_ret)
X_t_full<-cbind(
stats::lag(abs(daily_ret),k=1:q),
stats::lag(abs(X),k=1)) 

X_t_full<-replace(X_t_full,is.na(X_t_full),0)
X_t_oos<-zoo::coredata(X_t_full[(N_full-out_of_sample+1):N_full,])
X_t_oos<-as.data.frame(X_t_oos)
colnames(X_t_oos)<-colnames(X_t)
VaR_oos<-stats::predict(res,newdata=X_t_oos)

}


} else if (model=="lARCHX"&ES=="Yes"){
############################ construction of X_t matrix

X_t<-cbind(
rep(1,N),
stats::lag(abs(r_t_in_s),k=1:q),
stats::lag(abs(X_in_s),k=1)) 

X_t<-replace(X_t,is.na(X_t),0)

colnames(X_t)[1:(q+1)]<-paste("beta","_",0:q,sep="")
colnames(X_t)[(q+2)]<-paste("beta","_","X",sep="")

## Est.

X_t<-zoo::coredata(cbind(X_t[,2:(q+2)]))
Y<-zoo::coredata(r_t_in_s)
MAT<-data.frame(Y,X_t)
colnames(MAT)[1]<-"Y_t"
res<-rq(formula = Y_t ~ ., tau = tau, data=MAT)

start_val<-c(stats::coef(res),0)

names(start_val)[(q+3)]<-"theta_gamma"

res<- maxLik(lARCH_fun_es, 
start=start_val, 
ret=zoo::coredata(r_t_in_s),
X_t=cbind(1,X_t),
tau=tau,
method="BFGS")

VaR<-lARCH_var_es(stats::coef(res)[1:(q+2)],
zoo::coredata(r_t_in_s),cbind(1,X_t),tau=tau)
ES<-(1+exp(stats::coef(res)[q+3]))*VaR
ES<-as.xts(ES,stats::time(r_t_in_s))

################################ oos

if (!missing(out_of_sample)) {

N_full<-length(daily_ret)
X_t_full<-cbind(
stats::lag(abs(daily_ret),k=1:q),
stats::lag(abs(X),k=1)) 

X_t_full<-replace(X_t_full,is.na(X_t_full),0)
X_t_oos<-zoo::coredata(X_t_full[(N_full-out_of_sample+1):N_full,])
X_t_oos<-as.matrix(X_t_oos)
colnames(X_t_oos)<-colnames(X_t)
VaR_oos<-lARCH_var_es(stats::coef(res)[1:(q+2)],
zoo::coredata(r_t_oos),cbind(1,X_t_oos),tau=tau)
ES_oos<-(1+exp(stats::coef(res)[q+3]))*VaR_oos
ES_oos<-as.xts(ES_oos,stats::time(r_t_oos))

}
######################################################
} else if (model=="lARCHMIDAS"&ES=="No"){
ES<-ES_oos<-NA

X_t<-cbind(
rep(1,N),
stats::lag(abs(r_t_in_s),k=1:q)) 

X_t<-replace(X_t,is.na(X_t),0)

colnames(X_t)<-paste("beta","_",0:q,sep="")

## MIDAS variable inclusion with profiling

res_first_step<-list()
rho_est<-list()

w1<-1
w2_seq<-seq(1.0,10,0.1)

for(r in 1:length(w2_seq)){

w2<-w2_seq[r]

betas<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2))[2:(K+1)],0)
tau_d<- suppressWarnings(roll::roll_sum(mv_m_in_s, c(K+1),weights = betas))
tau_d<-tau_d[(K+1),]	 

X_t_2<-NULL
X_t_2<-zoo::coredata(cbind(X_t,abs(tau_d)))[,2:(q+2)]
colnames(X_t_2)[ncol(X_t_2)]<-c("theta")
Y<-coredata(r_t_in_s)
MAT<-data.frame(Y,X_t_2)
colnames(MAT)[1]<-"Y_t"

res_first_step[[r]]<-suppressWarnings(rq(formula = Y_t~ ., tau = tau,  data=MAT))
rho_est[[r]]<-res_first_step[[r]]$rho
}

rho_est<-unlist(rho_est)

################ find the optimal value of w2 and hence the optimal estimates

w2_star<-w2_seq[which.min(rho_est)]
r_star<-which.min(rho_est)

res<-(res_first_step[r_star])[[1]]

VaR<-stats::fitted.values(res)

################################ oos

if (!missing(out_of_sample)) {

N_full<-length(daily_ret)
X_t_full<-cbind(
stats::lag(abs(daily_ret),k=1:q)) 

X_t_full<-replace(X_t_full,is.na(X_t_full),0)
X_t_oos<-zoo::coredata(X_t_full[(N_full-out_of_sample+1):N_full,])


betas<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_star))[2:(K+1)],0)
tau_d<- suppressWarnings(roll::roll_sum(mv_m_oos, c(K+1),weights = betas))
tau_d<-tau_d[(K+1),]	 

X_t_oos<-as.data.frame(cbind(X_t_oos,abs(tau_d)))

colnames(X_t_oos)<-colnames(X_t_2)

VaR_oos<-stats::predict(res,newdata=X_t_oos)

}
########################################################
} else if (model=="lARCHMIDAS"&ES=="Yes"){

X_t<-cbind(
rep(1,N),
stats::lag(abs(r_t_in_s),k=1:q)) 

X_t<-replace(X_t,is.na(X_t),0)

colnames(X_t)<-paste("beta","_",0:q,sep="")

## MIDAS variable inclusion with profiling

res_first_step<-list()
rho_est<-list()

w1<-1
w2_seq<-seq(1.0,10,0.1)

for(r in 1:length(w2_seq)){

w2<-w2_seq[r]

betas<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2))[2:(K+1)],0)
tau_d<- suppressWarnings(roll::roll_sum(mv_m_in_s, c(K+1),weights = betas))
tau_d<-tau_d[(K+1),]	 

X_t_2<-NULL
X_t_2<-zoo::coredata(cbind(X_t,abs(tau_d)))[,2:(q+2)]
colnames(X_t_2)[ncol(X_t_2)]<-c("theta")
Y<-coredata(r_t_in_s)
MAT<-data.frame(Y,X_t_2)
colnames(MAT)[1]<-"Y_t"

res_first_step[[r]]<-suppressWarnings(rq(formula = Y_t~ ., tau = tau,  data=MAT))
rho_est[[r]]<-res_first_step[[r]]$rho
}

rho_est<-unlist(rho_est)

################ find the optimal value of w2 and hence the optimal estimates

w2_star<-w2_seq[which.min(rho_est)]
r_star<-which.min(rho_est)

res<-(res_first_step[r_star])[[1]]

############### Estimation via ALD

betas<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_star))[2:(K+1)],0)
tau_d<- suppressWarnings(roll::roll_sum(mv_m_in_s, c(K+1),weights = betas))
tau_d<-tau_d[(K+1),]	 

X_t_2<-NULL
X_t_2<-zoo::coredata(cbind(X_t,abs(tau_d)))[,2:(q+2)]
colnames(X_t_2)[ncol(X_t_2)]<-c("theta")
X_t<-X_t_2

start_val<-c(stats::coef(res),0)

names(start_val)[(q+3)]<-"theta_gamma"

res<- maxLik(lARCH_fun_es, 
start=start_val, 
ret=zoo::coredata(r_t_in_s),
X_t=cbind(1,X_t),
tau=tau,
method="BFGS")

VaR<-lARCH_var_es(stats::coef(res)[1:(q+2)],
zoo::coredata(r_t_in_s),cbind(1,X_t),tau=tau)
ES<-(1+exp(stats::coef(res)[q+3]))*VaR
ES<-as.xts(ES,stats::time(r_t_in_s))

################################ oos

if (!missing(out_of_sample)) {

N_full<-length(daily_ret)
X_t_full<-cbind(
stats::lag(abs(daily_ret),k=1:q)) 

X_t_full<-replace(X_t_full,is.na(X_t_full),0)
X_t_oos<-zoo::coredata(X_t_full[(N_full-out_of_sample+1):N_full,])

betas<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_star))[2:(K+1)],0)
tau_d<- suppressWarnings(roll::roll_sum(mv_m_oos, c(K+1),weights = betas))
tau_d<-tau_d[(K+1),]	 

X_t_oos<-as.data.frame(cbind(X_t_oos,abs(tau_d)))

colnames(X_t_oos)<-colnames(X_t_2)
X_t_oos<-as.matrix(X_t_oos)

VaR_oos<-lARCH_var_es(stats::coef(res)[1:(q+2)],
zoo::coredata(r_t_oos),cbind(1,X_t_oos),tau=tau)
ES_oos<-(1+exp(stats::coef(res)[q+3]))*VaR_oos
ES_oos<-as.xts(ES_oos,stats::time(r_t_oos))

}
######################################################
} else if (model=="lARCHMIDASX"&ES=="No"){
ES<-ES_oos<-NA
############################ construction of X_t matrix

X_t<-cbind(
rep(1,N),
stats::lag(abs(r_t_in_s),k=1:q),
stats::lag(abs(X_in_s),k=1)) 

X_t<-replace(X_t,is.na(X_t),0)

colnames(X_t)[1:(q+1)]<-paste("beta","_",0:q,sep="")
colnames(X_t)[(q+2)]<-paste("beta","_","X",sep="")

## MIDAS variable inclusion with profiling

res_first_step<-list()
rho_est<-list()

w1<-1
w2_seq<-seq(1.0,10,0.1)

for(r in 1:length(w2_seq)){

w2<-w2_seq[r]

betas<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2))[2:(K+1)],0)
tau_d<- suppressWarnings(roll::roll_sum(mv_m_in_s, c(K+1),weights = betas)) 
tau_d<-tau_d[(K+1),]	 

X_t_2<-NULL
X_t_2<-coredata(cbind(X_t,abs(tau_d)))[,2:(q+3)]
colnames(X_t_2)[ncol(X_t_2)]<-c("theta")
Y<-coredata(r_t_in_s)
MAT<-data.frame(Y,X_t_2)
colnames(MAT)[1]<-"Y_t"

res_first_step[[r]]<-suppressWarnings(rq(formula = Y_t~ ., tau = tau,  data=MAT))

rho_est[[r]]<-res_first_step[[r]]$rho
}

rho_est<-unlist(rho_est)

################ find the optimal value of w2 and hence the optimal estimates

w2_star<-w2_seq[which.min(rho_est)]
r_star<-which.min(rho_est)

res<-(res_first_step[r_star])[[1]]

VaR<-stats::fitted.values(res)

 
################################ oos

if (!missing(out_of_sample)) {

N_full<-length(daily_ret)
X_t_full<-cbind(
stats::lag(abs(daily_ret),k=1:q),
stats::lag(abs(X),k=1)) 

X_t_full<-replace(X_t_full,is.na(X_t_full),0)
X_t_oos<-zoo::coredata(X_t_full[(N_full-out_of_sample+1):N_full,])


betas<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_star))[2:(K+1)],0)
tau_d<- suppressWarnings(roll::roll_sum(mv_m_oos, c(K+1),weights = betas))
tau_d<-tau_d[(K+1),]	 

X_t_oos<-as.data.frame(cbind(X_t_oos,tau_d))

colnames(X_t_oos)<-colnames(X_t_2)

VaR_oos<-stats::predict(res,newdata=X_t_oos)

}
##################################################
} else if (model=="lARCHMIDASX"&ES=="Yes"){

X_t<-cbind(
rep(1,N),
stats::lag(abs(r_t_in_s),k=1:q),
stats::lag(abs(X_in_s),k=1)) 

X_t<-replace(X_t,is.na(X_t),0)

colnames(X_t)[1:(q+1)]<-paste("beta","_",0:q,sep="")
colnames(X_t)[(q+2)]<-paste("beta","_","X",sep="")

## MIDAS variable inclusion with profiling

res_first_step<-list()
rho_est<-list()

w1<-1
w2_seq<-seq(1.0,10,0.1)

for(r in 1:length(w2_seq)){

w2<-w2_seq[r]

betas<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2))[2:(K+1)],0)
tau_d<- suppressWarnings(roll::roll_sum(mv_m_in_s, c(K+1),weights = betas))
tau_d<-tau_d[(K+1),]	 

X_t_2<-NULL
X_t_2<-zoo::coredata(cbind(X_t,abs(tau_d)))[,2:(q+3)]
colnames(X_t_2)[ncol(X_t_2)]<-c("theta")
Y<-coredata(r_t_in_s)
MAT<-data.frame(Y,X_t_2)
colnames(MAT)[1]<-"Y_t"

res_first_step[[r]]<-suppressWarnings(rq(formula = Y_t~ ., tau = tau,  data=MAT))
rho_est[[r]]<-res_first_step[[r]]$rho
}

rho_est<-unlist(rho_est)

################ find the optimal value of w2 and hence the optimal estimates

w2_star<-w2_seq[which.min(rho_est)]
r_star<-which.min(rho_est)

res<-(res_first_step[r_star])[[1]]

############### Estimation via ALD

betas<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_star))[2:(K+1)],0)
tau_d<- suppressWarnings(roll::roll_sum(mv_m_in_s, c(K+1),weights = betas))
tau_d<-tau_d[(K+1),]	 

X_t_2<-NULL
X_t_2<-zoo::coredata(cbind(X_t,abs(tau_d)))[,2:(q+3)]
colnames(X_t_2)[ncol(X_t_2)]<-c("theta")
X_t<-X_t_2

start_val<-c(stats::coef(res),0)

names(start_val)[(q+4)]<-"theta_gamma"

res<- maxLik(lARCH_fun_es, 
start=start_val, 
ret=zoo::coredata(r_t_in_s),
X_t=cbind(1,X_t),
tau=tau,
method="BFGS")

VaR<-lARCH_var_es(stats::coef(res)[1:(q+3)],
zoo::coredata(r_t_in_s),cbind(1,X_t),tau=tau)
ES<-(1+exp(stats::coef(res)[q+4]))*VaR
ES<-as.xts(ES,stats::time(r_t_in_s))

################################ oos

if (!missing(out_of_sample)) {

N_full<-length(daily_ret)
X_t_full<-cbind(
stats::lag(abs(daily_ret),k=1:q),
stats::lag(abs(X),k=1)) 

X_t_full<-replace(X_t_full,is.na(X_t_full),0)
X_t_oos<-zoo::coredata(X_t_full[(N_full-out_of_sample+1):N_full,])

betas<-c(rev(rumidas::beta_function(1:(K+1),(K+1),w1,w2_star))[2:(K+1)],0)
tau_d<- suppressWarnings(roll::roll_sum(mv_m_oos, c(K+1),weights = betas))
tau_d<-tau_d[(K+1),]	 

X_t_oos<-as.data.frame(cbind(X_t_oos,abs(tau_d)))

colnames(X_t_oos)<-colnames(X_t_2)
X_t_oos<-as.matrix(X_t_oos)

VaR_oos<-lARCH_var_es(stats::coef(res)[1:(q+3)],
zoo::coredata(r_t_oos),cbind(1,X_t_oos),tau=tau)
ES_oos<-(1+exp(stats::coef(res)[q+4]))*VaR_oos
ES_oos<-as.xts(ES_oos,stats::time(r_t_oos))

}
######################################################
}


######## in-sample and out-of-sample estimation and evaluation



if (missing(out_of_sample)){

res_f<-list(
model=model,
coef_mat=summary(res),
obs=N,
period=range(stats::time(r_t_in_s)),
VaR=as.xts(VaR,stats::time(r_t_in_s)),
ES=ES,
hit_in_s=sum(ifelse(r_t_in_s<=VaR,1,0))/N,
loss_in_s=QL(r_t_in_s,VaR,tau)
)

} else {

res_f<-list(
model=model,
coef_mat=summary(res),
obs=N,
period=range(stats::time(r_t_in_s)),
VaR=as.xts(VaR,stats::time(r_t_in_s)),
ES=ES,
hit_in_s=sum(ifelse(r_t_in_s<=VaR,1,0))/N,
loss_in_s=QL(r_t_in_s,VaR,tau),
VaR_oos=as.xts(VaR_oos,stats::time(r_t_oos)),
ES_oos=ES_oos
)
}

class(res_f)<-c("rqmidas")

return(res_f)
print.rqmidas(res_f)


}




