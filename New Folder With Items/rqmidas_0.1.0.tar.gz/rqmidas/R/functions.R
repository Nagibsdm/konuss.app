#' Quantile loss function
#'
#' Function for obtaining the Quantile Loss \insertCite{koenker_bassett_1978}{rqmidas}.
#' @param ret Daily returns.
#' @param VAR Value-at-Risk.
#' @param alpha Quantile used.
#' @return The resulting vector represents the values of the Quantile Loss for each day.
#' @importFrom Rdpack reprompt
#' @keywords internal

QL<-function(ret,VAR,alpha){

Ind<-ifelse(ret<=VAR,1,0)

return((ret-VAR)*(alpha-Ind))

}

#' Print method for "rqmidas" class
#'
#' @param x An object of class "rqmidas".
#' @param ... Further arguments passed to or from other methods.
#' @keywords internal
#' @export print.rqmidas 
#' @export
print.rqmidas <- function(x, ...) {

cat(utils::capture.output(x$coef_mat),  sep = '\n')

}

#' Summary method for "rqmidas" class
#'
#' @param object An object of class "rqmidas", that is the result of a call to \code{\link{uqfit}}.
#' @param ... Additional arguments affecting the summary produced.
#' @examples
#' 
#' r_t<-sp500['2003/2010']
#' fit<-uqfit(model="lARCH",tau=0.05,daily_ret=r_t,q=5)
#' summary.rqmidas(fit)
#' @importFrom utils capture.output
#' @export summary.rqmidas
#' @export
summary.rqmidas <- function(object, ...) {

model<-object$model
mat_coef<-object$coef_mat
Obs<-object$obs
Period<-object$period
loss<-round(100*mean(object$loss_in_s),6)
var_viol<-round(object$hit_in_s*100,6)


Period<-paste(substr(Period[1], 1, 10),"/",
substr(Period[2], 1, 10),sep="")


cat(
cat("\n"),
cat("Coefficients:\n"),
cat(utils::capture.output(mat_coef),  sep = '\n'),
cat("--- \n"),
cat("Obs.:", paste(Obs, ".",sep=""), "Sample Period:", Period, "\n"),
cat("QL(%): ", loss, "\n"),
cat("VaR Viol.(%): ", var_viol, "\n"),
cat("\n"))


}








